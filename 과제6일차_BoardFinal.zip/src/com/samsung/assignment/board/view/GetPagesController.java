package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.controller.Controller;

public class GetPagesController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		BoardDAO dao = new BoardDAO();
		// 총 게시글 수를 가져옴
		int boards = dao.getPagingNum();
		// 게시글이 10의 배수이면
		int pages = 0;
		if(boards%10==0){
			// 페이지는 boards/10
			pages = boards/10;
		}else{
			// 그렇지 않으면 1페이지 추가
			pages = (boards/10)+1;
		}
		return pages;
	}

}
