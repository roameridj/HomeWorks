package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.Controller;

/**
 * 
 * @author student
 *
 */
public class ReplyController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		
		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoardView(vo);
		int grandParentBoardSeq = dao.selectBoardSeq(board_seq);
		// 원글 넣어서 돌려보내기
		request.setAttribute("parentBoard", board);
		// 가장 첫번째 글도 함께 넣기
		request.setAttribute("grandParentBoardSeq", grandParentBoardSeq);
		return "reply.jsp";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

}
