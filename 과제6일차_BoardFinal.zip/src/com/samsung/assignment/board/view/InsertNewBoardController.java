package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.Controller;
/**
 * 새글을 저장하는 Controller
 * @author student
 *
 */
public class InsertNewBoardController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		if(session.getAttribute("user_id")==null){
			request.setAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "getBoardList.do";
		}
		
		String user_id = (String) session.getAttribute("user_id");
		String board_title = request.getParameter("board_title");
		String board_content = request.getParameter("board_content");
		
		BoardVO vo = new BoardVO();
		vo.setUser_id(user_id);
		vo.setBoard_title(board_title);
		vo.setBoard_content(board_content);
		
		BoardDAO dao = new BoardDAO();
		boolean done = dao.insertNewBoard(vo);
		if(done){
			return "getBoardList.do";
		}else{
			request.setAttribute("msg", "게시글 DB에 저장 실패!");
			request.setAttribute("writingBoard", vo);
			return "write.jsp";
		}
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

}
