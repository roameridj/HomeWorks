package com.samsung.assignment.board.view;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.AdvancedPageUtility;
import com.samsung.assignment.controller.Controller;

public class GetBoardListController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		int pageNum = 1;
		if(request.getParameter("pageNo")!=null){
			pageNum = Integer.parseInt(request.getParameter("pageNo"));
		}
		BoardDAO dao = new BoardDAO();
		int interval = 10;
		// 게시글 전체 가져오기
		ArrayList<BoardVO> boardList = dao.list(pageNum, interval);
		// 게시글 수 가져오기
		int total = dao.listCount();
		// total이 0이면 1, 아니면 total
		total = total==0?1:total;
		try {
			AdvancedPageUtility bar = new AdvancedPageUtility(interval, total, pageNum, "images/");
			request.setAttribute("pageLink", bar.getPageBar());
			request.setAttribute("boardList", boardList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "board.jsp";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		return null;
	}

}
