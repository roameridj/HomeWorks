package com.samsung.assignment.users.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.assignment.controller.Controller;
import com.samsung.assignment.users.impl.UserDAO;
import com.samsung.assignment.users.vo.UserVO;

public class MemberJoin implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		UserDAO dao = new UserDAO();
		UserVO vo = new UserVO();
		vo.setUser_id(request.getParameter("id"));
		vo.setPassword(request.getParameter("password"));
		vo.setUser_name(request.getParameter("name"));
		vo.setUser_email(request.getParameter("email"));
		
		dao.registerUser(vo);
		return "board.jsp";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		
		return null;
	}

}
