package com.samsung.assignment.users.view;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.controller.Controller;
import com.samsung.assignment.users.impl.UserDAO;
import com.samsung.assignment.users.vo.UserVO;

public class LoginController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		String user_id = request.getParameter("user_id");
		String password = request.getParameter("password");
		
		UserVO vo = new UserVO();
		vo.setUser_id(user_id);
		vo.setPassword(password);
		UserDAO dao = new UserDAO();
		
		UserVO loginUser = dao.login(vo);
		String msg = "";
		if(loginUser.getUser_id()==null){
			msg = "아이디를 확인하세요";
			request.setAttribute("msg", msg);
		}else if(loginUser.getPassword().equals("uncorrect")){
			msg = "비밀번호를 확인하세요";
			request.setAttribute("inputId", user_id);
			request.setAttribute("msg", msg);
		}else{
			HttpSession session = request.getSession();
			session.setAttribute("user_id", loginUser.getUser_id());
			session.setAttribute("user_name", loginUser.getUser_name());
			msg = "성공";
		}
		// 게시글 가져가기
		return "getBoardList.do";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		String user_id = request.getParameter("user_id");
		String password = request.getParameter("password");
		
		UserVO vo = new UserVO();
		vo.setUser_id(user_id);
		vo.setPassword(password);
		
		UserDAO dao = new UserDAO();
		
		UserVO loginUser = dao.login(vo);
		String json = "";
		Gson gson = new Gson();
		
		if(loginUser.getUser_id()==null){
			json = "아이디를 확인하세요";
		}else if(loginUser.getPassword().equals("uncorrect")){
			json = "비밀번호를 확인하세요";
		}else{
			HttpSession session = request.getSession();
			session.setAttribute("user_id", loginUser.getUser_id());
			session.setAttribute("user_name", loginUser.getUser_name());
			json = "성공";
			HashMap<String, Object> map = new HashMap<>();
			map.put("msg", json);
			map.put("user", gson.toJson(loginUser));
		}
		try {
			response.getWriter().write(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
