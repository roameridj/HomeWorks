package com.samsung.assignment.users.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.assignment.controller.Controller;
import com.samsung.assignment.users.impl.UserDAO;
import com.samsung.assignment.users.vo.UserVO;

public class IDCheck implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		UserDAO dao = new UserDAO();
		UserVO vo = new UserVO();
		vo.setUser_id(request.getParameter("id"));
		request.setAttribute("yesno", dao.checkID(vo));
		return "registerUser.jsp";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		
		return null;
	}

}
