package com.samsung.assignment.users.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.assignment.users.vo.UserVO;
import com.samsung.assignment.utils.JDBCUtil;

public class UserDAO {
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	/**
	 * 로그인
	 * @param vo
	 * @return
	 */
	public UserVO login(UserVO vo){
		UserVO user = new UserVO();
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT USER_ID, PASSWORD, USER_NAME FROM USERS WHERE USER_ID = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getUser_id());
			rs = stmt.executeQuery();
			// 해당하는 아이디가 없으면 null인 vo를 리턴
			if(!rs.next()){
			}else{
				// 아이디는 일치하지만 비밀번호가 일치하지 않는 경우
				if(!vo.getPassword().equals(rs.getString("password"))){
					user = new UserVO("uncorrect", "uncorrect", "", "");
				}else{
					// 아이디와 비밀번호가 일치하는 경우
					user = new UserVO(rs.getString("user_id"), "", rs.getString("user_name"), "");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return user;
	}
	
	/**
	 * 회원가입
	 * @param vo
	 * @return
	 */
	public UserVO registerUser(UserVO vo){
		UserVO user = new UserVO();
		try {
			conn = JDBCUtil.getConnection();
			String sql = "insert into users values(?, ?, ?, ?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getUser_id());
			stmt.setString(2, vo.getPassword());
			stmt.setString(3, vo.getUser_name());
			stmt.setString(4, vo.getUser_email());
			stmt.executeUpdate();
			// 해당하는 아이디가 없으면 null인 vo를 리턴
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return null;
	}
	
	/**
	 *아이디 중복체크 
	 */
	public String checkID(UserVO vo){
		
		String yesno = "";
		try{
			conn = JDBCUtil.getConnection();
			String sql = "select * from users where user_id=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getUser_id());
			rs=stmt.executeQuery();
			if(rs.next()){
				yesno = "used";
			}else{
				yesno = "available";
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return yesno;
	}
	
}
