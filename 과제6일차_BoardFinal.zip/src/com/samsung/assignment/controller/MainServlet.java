package com.samsung.assignment.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8");
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		// 수행할 명령 가져오기
		String uri = request.getRequestURI();
		// 수행할 명령을 추출. 예) ㅣogin.do
		String path = uri.substring(uri.lastIndexOf("/"));
		
		// 컨트롤러 연결
		HandlerMapping handler = new HandlerMapping();
		if(path.substring(path.lastIndexOf(".")).equals(".go")){
			// 비동기 방식 처리
			Controller ctrl = handler.getController(path);
			Object obj = ctrl.jqueryRequest(request, response);
			response.getWriter().write(new Gson().toJson(obj));
		}else{
			Controller ctrl = handler.getController(path);
			// 각 컨트롤러에서 다음 이동할 경로를 가져옴
			String nextPage = ctrl.handleRequest(request, response);
			// 다음 이동할 경로 전달
			request.getRequestDispatcher(nextPage).forward(request, response);
		}
	}

}
