package com.samsung.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import com.samsung.assignment.board.view.DeleteBoardController;
import com.samsung.assignment.board.view.GetBoardListController;
import com.samsung.assignment.board.view.GetBoardViewController;
import com.samsung.assignment.board.view.GetPagesController;
import com.samsung.assignment.board.view.InsertNewBoardController;
import com.samsung.assignment.board.view.InsertReplyController;
import com.samsung.assignment.board.view.ReplyController;
import com.samsung.assignment.board.view.SearchController;
import com.samsung.assignment.board.view.UpdateSaveController;
import com.samsung.assignment.users.view.IDCheck;
import com.samsung.assignment.users.view.LoginController;
import com.samsung.assignment.users.view.LogoutController;
import com.samsung.assignment.users.view.MemberJoin;

public class HandlerMapping {
	/**
	 *  mapping HashMap 선언
	 */
	private Map<String, Controller> mapping;
	
	/**
	 *  HashMap 생성 및 컨트롤러 연결을 위한 생성자
	 */
	public HandlerMapping(){
		mapping = new HashMap<>();
		mapping.put("/login.do", new LoginController());
		mapping.put("/logout.do", new LogoutController());
		mapping.put("/getPages.go", new GetPagesController());
		mapping.put("/getBoardList.do", new GetBoardListController());
		mapping.put("/getBoardView.do", new GetBoardViewController());
		mapping.put("/updateSave.go", new UpdateSaveController());
		mapping.put("/insertNewBoard.do", new InsertNewBoardController());
		mapping.put("/deleteBoard.do", new DeleteBoardController());
		mapping.put("/reply.do", new ReplyController());
		mapping.put("/insertReplyBoard.do", new InsertReplyController());
		mapping.put("/search.do", new SearchController());
		mapping.put("/memberjoin.do", new MemberJoin());
		mapping.put("/idcheck.do", new IDCheck());
	}
	
	/**
	 *  컨트롤러 리턴을 위한 메서드 
	 * @param path
	 * @return
	 */
	public Controller getController(String path){
		return mapping.get(path);
	}
}
